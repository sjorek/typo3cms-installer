<?php

namespace Namespaced;

class Bar
{
    public static $loaded = true;
}
