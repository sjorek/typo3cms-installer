<?php

namespace ClassMap;

class SomeClass extends SomeParent implements SomeInterface
{

}
