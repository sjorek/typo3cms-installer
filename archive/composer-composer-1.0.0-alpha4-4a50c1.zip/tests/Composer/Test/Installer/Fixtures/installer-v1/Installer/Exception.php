<?php

namespace Installer;

class Exception extends \Exception
{
}
