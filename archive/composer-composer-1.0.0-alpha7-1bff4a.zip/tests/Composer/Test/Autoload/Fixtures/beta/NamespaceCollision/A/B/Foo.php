<?php

namespace NamespaceCollision\A\B;

class Foo
{
    public static $loaded = true;
}
